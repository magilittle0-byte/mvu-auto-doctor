import { isPlainObject } from '../domain/common.mjs';

const SHA256_CONSTANTS = Object.freeze([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

function rotateRight(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
}

function utf8Bytes(text) {
    if (typeof TextEncoder === 'function') return new TextEncoder().encode(text);
    const encoded = unescape(encodeURIComponent(text));
    return Uint8Array.from(encoded, (character) => character.charCodeAt(0));
}

export function sha256Text(text) {
    const source = utf8Bytes(String(text));
    const bitLength = source.length * 8;
    const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
    const bytes = new Uint8Array(paddedLength);
    bytes.set(source);
    bytes[source.length] = 0x80;
    const view = new DataView(bytes.buffer);
    const high = Math.floor(bitLength / 0x100000000);
    const low = bitLength >>> 0;
    view.setUint32(paddedLength - 8, high);
    view.setUint32(paddedLength - 4, low);

    const state = new Uint32Array([
        0x6a09e667,
        0xbb67ae85,
        0x3c6ef372,
        0xa54ff53a,
        0x510e527f,
        0x9b05688c,
        0x1f83d9ab,
        0x5be0cd19,
    ]);
    const words = new Uint32Array(64);

    for (let offset = 0; offset < bytes.length; offset += 64) {
        for (let index = 0; index < 16; index += 1) {
            words[index] = view.getUint32(offset + (index * 4));
        }
        for (let index = 16; index < 64; index += 1) {
            const left = words[index - 15];
            const right = words[index - 2];
            const sigma0 = rotateRight(left, 7) ^ rotateRight(left, 18) ^ (left >>> 3);
            const sigma1 = rotateRight(right, 17) ^ rotateRight(right, 19) ^ (right >>> 10);
            words[index] = (
                words[index - 16]
                + sigma0
                + words[index - 7]
                + sigma1
            ) >>> 0;
        }

        let [a, b, c, d, e, f, g, h] = state;
        for (let index = 0; index < 64; index += 1) {
            const sum1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
            const choice = (e & f) ^ (~e & g);
            const temporary1 = (
                h
                + sum1
                + choice
                + SHA256_CONSTANTS[index]
                + words[index]
            ) >>> 0;
            const sum0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
            const majority = (a & b) ^ (a & c) ^ (b & c);
            const temporary2 = (sum0 + majority) >>> 0;
            h = g;
            g = f;
            f = e;
            e = (d + temporary1) >>> 0;
            d = c;
            c = b;
            b = a;
            a = (temporary1 + temporary2) >>> 0;
        }
        state[0] = (state[0] + a) >>> 0;
        state[1] = (state[1] + b) >>> 0;
        state[2] = (state[2] + c) >>> 0;
        state[3] = (state[3] + d) >>> 0;
        state[4] = (state[4] + e) >>> 0;
        state[5] = (state[5] + f) >>> 0;
        state[6] = (state[6] + g) >>> 0;
        state[7] = (state[7] + h) >>> 0;
    }

    return [...state]
        .map((word) => word.toString(16).padStart(8, '0'))
        .join('');
}

function canonicalValue(value, seen) {
    if (value === null) return 'null';
    if (typeof value === 'string') return `string:${JSON.stringify(value)}`;
    if (typeof value === 'boolean') return `boolean:${value ? '1' : '0'}`;
    if (typeof value === 'number') {
        if (!Number.isFinite(value)) {
            throw new TypeError('规范哈希不接受 NaN 或 Infinity。');
        }
        return `number:${Object.is(value, -0) ? '-0' : String(value)}`;
    }
    if (Array.isArray(value)) {
        if (seen.has(value)) throw new TypeError('规范哈希不接受循环引用。');
        seen.add(value);
        const result = `array:[${value.map((entry) => canonicalValue(entry, seen)).join(',')}]`;
        seen.delete(value);
        return result;
    }
    if (isPlainObject(value)) {
        if (seen.has(value)) throw new TypeError('规范哈希不接受循环引用。');
        seen.add(value);
        const result = `object:{${Object.keys(value)
            .sort()
            .map((key) => `${JSON.stringify(key)}=${canonicalValue(value[key], seen)}`)
            .join(',')}}`;
        seen.delete(value);
        return result;
    }
    throw new TypeError(`规范哈希不接受 ${typeof value}。`);
}

export function canonicalSerialize(value) {
    return canonicalValue(value, new WeakSet());
}

export function hashCanonical(value) {
    return `sha256:${sha256Text(canonicalSerialize(value))}`;
}

export function hashText(value) {
    return `sha256:${sha256Text(String(value))}`;
}
